<?php
$servername = "localhost";
$username = "root"; // Default XAMPP MySQL user
$password = ""; // No password by default
$dbname = "registration_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
